import React from "react";

import classes from "./ActiveTodos.css";

const ActiveTodos = (props) => {
        let activeTodoTemplate = null;
        if(props.todoLists.length > 0) {
        let updatedTodos = props.todoLists.filter((todo)=>{
            return todo.status === "incomplete"
        })
        activeTodoTemplate = updatedTodos.map((todo,index) => {
            let id = "Checkbox" + index;
            let allClasses = [classes.todoLabel];
            return (
                <div key = {index} className = {classes.TodoList}>
                    <input  
                        className = {classes.Checkbox}
                        id={id}
                        type="checkbox" 
                        value="value1" 
                        onChange = {()=>props.checked(todo.todoName)}/>
                    
                        <label 
                            className = {allClasses.join(' ')}
                            for={id}>{todo.todoName}</label>
                        <span 
                            className = {["fa fa-times", classes.deleteIcon].join(' ')}
                            onClick = {()=>props.deleteActiveTodo(todo.todoName)}></span>
                </div>
            )
        })
    }
        return (
            <div className = {classes.ActiveTodos}>
                 {activeTodoTemplate}
            </div>
         )
}

export default ActiveTodos;