import React from "react";

import classes from "./CompletedTodos.css";

const CompletedTodos = (props) => {
    let completeTodoTemplate = null;
    if(props.todoLists.length > 0) {
        let updatedTodos = props.todoLists.filter((todo)=>{
            return todo.status === "completed"
        })
        completeTodoTemplate = updatedTodos.map((todo,index) => {
            let id = "Checkbox" + index;
            let allClasses = [classes.todoLabel];
            if(todo.status === 'completed') {
                allClasses.push(classes.CompletedTodo);
            }
            return (
                <div key = {index} className = {classes.TodoList}>
                    <input  
                        className = {classes.Checkbox}
                        id={id}
                        type="checkbox" 
                        value="value1"
                        checked = {todo.status === "completed" ? "checked": ""} 
                        onChange = {()=>props.checked(todo.todoName)}/>
                    <label 
                       className = {allClasses.join(' ')}
                        for={id}>{todo.todoName}</label>
                    <span 
                        className = {["fa fa-times", classes.deleteIcon].join(' ')}
                        onClick = {()=>props.deleteCompletedTodo(todo.todoName)}></span>
                </div>
            )
        })
    }
    return (
       <div className = {classes.CompleteTodos}>
         {completeTodoTemplate}
       </div>
    )
}

export default  CompletedTodos;