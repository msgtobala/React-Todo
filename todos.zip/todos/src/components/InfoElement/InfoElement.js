import React from "react";

import classes from "./InfoElement.css";

const InfoElement = (props) => {
    return (
        <div className = {classes.InfoElement}>
            <p>Double-click to edit a todo</p>
            <p>Created by Balaji</p>
            <p>Part of Todo</p>
        </div>
    )
}

export default InfoElement;