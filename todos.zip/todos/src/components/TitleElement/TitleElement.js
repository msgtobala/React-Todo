import React from 'react';

import classes from "./TitleElement.css"

const TitleElement = () => {
   return (
    <div>
        <h1 className = {classes.TitleElement}>todos</h1>
    </div>
   )
}

export default TitleElement;
