import React from "react";

import classes from "./TodoControls.css";
import {NavLink} from "react-router-dom";

const TodoControls = (props) => {

    let todoControls = null;

    if(props.todoLists.length > 0) {
        todoControls = (
            <div className = {classes.TodoControls}>
                <div className = {classes.TotalItems}>
                    <p><span>{props.totalTodos}</span> item(s) left</p>
                </div>
                <div className = {classes.Controls}>
                    <ul className = {classes.ControlsLists}>
                        <li>
                            <NavLink exact to = {{
                                pathname: '/'
                            }} activeClassName = {classes.active}>All</NavLink>
                        </li>
                        <li>
                            <NavLink exact to = {{
                                pathname: '/active'
                            }} activeClassName = {classes.active}>Active</NavLink>
                        </li>
                        <li>
                            <NavLink exact to = {{
                                pathname: '/completed'
                            }} activeClassName = {classes.active}>Completed</NavLink>
                        </li>
                    </ul>
                </div>
                <div className = {classes.ClearSelection}>
                    <span onClick = {props.clearCompleted}>Clear Completed</span>
                </div>
            </div>
        )
    }

    return todoControls;
}

export default TodoControls;