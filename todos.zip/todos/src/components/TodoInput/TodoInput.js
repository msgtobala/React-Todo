import React from "react";

import classes from "./TodoInput.css";

const TodoInput = (props) => {
    
    let allClasses  = [classes.enableArrow]
    if(props.toggled === false) {
        allClasses.push(classes.ColoredToggle)
    }
    return (
        <div className = {classes.TodoInputs}>
            <input 
                className = {classes.TodoInput}
                placeholder = "What needs to be done?"
                onChange = {props.changed}
                onKeyDown = {props.saved} 
                value = {props.value} />
            <span 
                className = {allClasses.join(' ')}
                onClick = {props.changeAllStatus}></span>
        </div>
    )
}

export default TodoInput;