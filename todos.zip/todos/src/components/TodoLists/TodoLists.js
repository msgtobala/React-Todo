import React from "react";

import classes from "./TodoLists.css";

const TodoLists = (props) => {

    let todoListTemplate = null;
    if(props.todoLists.length > 0) {
       todoListTemplate = props.todoLists.map((todo,index)=>{
           let allClasses = [classes.todoLabel];
           if(todo.status === 'completed') {
                allClasses.push(classes.CompletedTodo);
           }
           let id = "Checkbox" + index
           return (
            <div className = {classes.TodoList} key = {index}>
                <input  
                    className = {classes.Checkbox}
                    id={id}
                    type="checkbox" 
                    value="value1" 
                    checked = {todo.status === "completed" ? "checked": ""}
                    onChange = {()=>props.checked(index)}/>
                <label 
                    className = {allClasses.join(' ')}
                    for={id}>{todo.todoName}</label>
                <span 
                    className = {["fa fa-times", classes.deleteIcon].join(' ')}
                    onClick = {()=>props.deleteTodo(index)}></span>
            </div>
           )
       })
    }

    return (
        <div className = {classes.TodoLists}>
            {todoListTemplate}
        </div>
    );
}

export default TodoLists;