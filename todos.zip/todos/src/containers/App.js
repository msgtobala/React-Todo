import React, { Component } from 'react';
import {Route, Switch} from "react-router-dom";

import classes from './App.css';
import TitleElement from "../components/TitleElement/TitleElement";
import TodoInput from "../components/TodoInput/TodoInput";
import TodoList from "../components/TodoLists/TodoLists";
import TodoControls from "../components/TodoControls/TodoControls";
import ActiveTodos from "../components/ActiveTodos/ActiveTodos";
import CompletedTodos from "../components/CompletedTodos/CompletedTodos";
import InfoElement from "../components/InfoElement/InfoElement";

class App extends Component {

  state = {
    todos: [],
    totalTodos: 0,
    currValue: "",
    toggled: true
  }

  addTodoHandler = (event) => {
      const newTodo = event.target.value;
      this.setState({currValue: newTodo})
  }

  saveTodoHndler = (event) => {
    const newTodo = this.state.currValue;
    let newTodoObj;
    if(event.which === 13 || event.keyCode === 13) {
      newTodoObj = {
        "todoName": newTodo,
        "status": "incomplete"
      }
      let updatedTodos = [...this.state.todos];
      updatedTodos.push(newTodoObj);
      this.setState({todos: updatedTodos,currValue: "",totalTodos: this.state.totalTodos + 1});
    }
  }

  changeStatusHandler = (index) => {
    let updatedTodos = [...this.state.todos];
    if(updatedTodos[index].status === "incomplete") {
      updatedTodos[index].status = "completed";
      this.setState({todos: updatedTodos,totalTodos: this.state.totalTodos - 1});
    }else if(updatedTodos[index].status === "completed") {
      updatedTodos[index].status = "incomplete";
      this.setState({todos: updatedTodos, totalTodos: this.state.totalTodos + 1});
    }
  }

  changeAllStatusHandler = () => {
    this.setState({toggled: !this.state.toggled});
    if(this.state.toggled) {
      let updatedTodos = [...this.state.todos];
      for(let itr in updatedTodos) {
        updatedTodos[itr].status = "completed";
        let id = "Checkbox" + itr; 
        document.getElementById(id).checked = true;
      }
      this.setState({todos: updatedTodos, totalTodos: 0});
    }else {
      let updatedTodos = [...this.state.todos];
      for(let itr in updatedTodos) {
        updatedTodos[itr].status = "incomplete";
        let id = "Checkbox" + itr; 
        document.getElementById(id).checked = false;
      } 
      this.setState({todos: updatedTodos, totalTodos: this.state.todos.length});
    }
  }

  clearSelectionHandler = () => {
    let Todos = [...this.state.todos];
    let updatedTodos = Todos.filter((itr)=>{
      return itr.status === "incomplete"
    })
    this.setState({todos: updatedTodos});
  }

  updateCompletedTodos = (todo) => {
    let updatedTodos = [...this.state.todos];
    const index = updatedTodos.findIndex((element)=>{
      return element.todoName === todo
    })
    updatedTodos[index].status = "incomplete";
    this.setState({todos: updatedTodos})
  }

  updateActiveTodos = (todo) => {
    let updatedTodos = [...this.state.todos];
    const index = updatedTodos.findIndex((element)=>{
      return element.todoName === todo
    })
    updatedTodos[index].status = "completed";
    this.setState({todos: updatedTodos});
  }

  deleteTodoHandler = (index) => {
    let updatedTodos = [...this.state.todos];
    updatedTodos.splice(index, 1);
    this.setState({todos: updatedTodos, totalTodos: this.state.totalTodos - 1})
  }
  
  deleteActiveTodoHandler = (todoName) => {
    let updatedActiveTodos = [...this.state.todos];
    const index = updatedActiveTodos.findIndex((element)=>{
      return element.todoName === todoName
    })
    updatedActiveTodos.splice(index, 1);
    this.setState({todos: updatedActiveTodos, totalTodos: this.state.totalTodos - 1})
  }

  deleteCompletedTodo = (todoName) => {
    let updatedCompletedTodos = [...this.state.todos];
    const index = updatedCompletedTodos.findIndex((element)=>{
      return element.todoName === todoName
    })
    updatedCompletedTodos.splice(index, 1);
    this.setState({todos: updatedCompletedTodos});
  }

  render() {
    return (
      <div className={classes.App}>
        <TitleElement />
        <div className = {classes.TodoContainer}>
          <TodoInput 
            todos = {this.state.todos}
            value = {this.state.currValue}
            changed = {(event)=>this.addTodoHandler(event)}
            saved = {(event)=>this.saveTodoHndler(event)}
            changeAllStatus = {this.changeAllStatusHandler}
            toggled = {this.state.toggled} />
            <Switch>
              <Route exact path = "/active" render = {()=>(<ActiveTodos 
                                                              todoLists = {this.state.todos}
                                                              checked = {this.updateActiveTodos}
                                                              deleteActiveTodo = {this.deleteActiveTodoHandler}/>)} />
              <Route exact path = "/completed" render = {()=>(<CompletedTodos 
                                                              todoLists = {this.state.todos}
                                                              checked = {this.updateCompletedTodos}
                                                              deleteCompletedTodo = {this.deleteCompletedTodo}/>)}/>
              <Route exact path = "/" render = {()=>(<TodoList checked = {this.changeStatusHandler}
                                                              todoLists = {this.state.todos} 
                                                              deleteTodo = {this.deleteTodoHandler}/>)}/>
            </Switch>
          <TodoControls 
            todoLists = {this.state.todos}
            totalTodos = {this.state.totalTodos}
            clearCompleted = {this.clearSelectionHandler}/>
        </div>
        <InfoElement />
      </div>
    );
  }
}

export default App;
